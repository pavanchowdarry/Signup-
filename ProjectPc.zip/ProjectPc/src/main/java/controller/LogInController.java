package controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.SignUpDao;

@WebServlet("/login")


	
	public class LogInController extends HttpServlet {
	    @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        String name = req.getParameter("Your Name");
	        String pass = req.getParameter("Password");
             SignUpDao da= new SignUpDao();
             da.logIn(name, pass);
	        // TODO: Query the database to validate the login credentials
	        boolean isValidUser = validateCredentials(name, pass);

	        if (isValidUser) {
	            // Create a session to maintain the user's authentication
	            HttpSession session = req.getSession(true);
	            session.setAttribute("user", name);

	            // Redirect to a success page (e.g., dashboard)
	            resp.sendRedirect("/Project1/dashboard.jsp");
	        } else {
	            // Redirect to a login failure page
	            resp.sendRedirect("/Project1/login.jsp?error=1");
	        }
	    }

	    // TODO: Implement a method to validate user credentials against the database
	    private boolean validateCredentials(String name, String pass) {
	        // Perform database validation here
	        // Return true if the credentials are valid; otherwise, return false
	        // You should use a secure method to validate passwords (e.g., hash and compare)
	        // This is just a placeholder method; replace it with actual validation logic
	        return (name != null && pass != null && name.equals("validName") && pass.equals("validPassword"));
	    }
	}


	

