package dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SignUpPage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int UserId;
	private String UserName;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	private String UserEmail ;
	private String UserPassword;
	private String UserRePassword;
	private long UserContactNumber;
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	public String getUserRePassword() {
		return UserRePassword;
	}
	public void setUserRePassword(String userRePassword) {
		UserRePassword = userRePassword;
	}
	public long getUserContactNumber() {
		return UserContactNumber;
	}
	public void setUserContactNumber(long userContactNumber) {
		UserContactNumber = userContactNumber;
	}
	


}
