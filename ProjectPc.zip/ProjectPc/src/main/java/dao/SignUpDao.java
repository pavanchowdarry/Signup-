package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


import dto.SignUpPage;

public class SignUpDao {
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pavan");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();

	public void signUp(SignUpPage page)
	{
		entityTransaction.begin();
		entityManager.persist(page);
		entityTransaction.commit();
		
	}
	
	
	
	public SignUpDao logIn(String Name, String Password) {
	    TypedQuery<SignUpDao> query = entityManager.createQuery(
	        "SELECT s FROM SignUpDao s WHERE s.name = :name AND s.password = :password", SignUpDao.class );
	    query.setParameter("name", Name);
	    query.setParameter("password", Password);

	    List<SignUpDao> resultList = query.getResultList();
	    if (!resultList.isEmpty()) {
	        // User with the given Name and Password exists, return the first match
	        return resultList.get(0);
	        
	    } else {
	        // No user found with the given Name and Password
	        return null;
	    }
	}

}
